import threading
import time
from cores import *

# afn_teste = {
#     "alfabeto" : ["0","1"]
#     "estados" : ["q0","q1","q2"]
#     "inicial" : "q0",
#     "finais" : ["q2"],
#     "transicoes": {
#         "q0,0" : ["q0"],
#         "q0,1" : ["q0", "q1"],
#         "q1,1" : ["q2"],
#         "q2,0" : ["q2"],
#         "q2,1" : ["q2"]
#     },
#     "threads_iniciais": 1
# }

afn = {} #Dicionário em que será inserido o AFN

afn_antigo = {} #Dicionário em que o AFN anterior é guardado

arquivo_nome = "" #Nome do arquivo em que está a AFN

numero_threads = 0 #Número de threads, para que seja calculado o id de cada uma

string_threads = [] #Strings dos processamentos das threads

locks = [threading.Lock(), threading.Lock(), threading.Lock(), threading.Lock(), threading.Lock()]

def mostrarAFN():
    global arquivo_nome

    try:
        with open(arquivo_nome, "r") as f:
            arquivo = open(arquivo_nome, "r")
    except IOError:
        print(f"{colors.FAIL}Nenhum AFN registrado{colors.RESET}")
        return

    linhas = arquivo.readlines()
    for i in range(len(linhas)):
        print(linhas[i].replace(" ", "").replace("\n", "").strip())

    print()

    arquivo.close()

def registrarArquivo(nome_arquivo: str):
    global arquivo_nome
    global afn
    global afn_antigo

    afn_antigo = dict(afn)

    if arquivoValido(nome_arquivo) == True: #Se o arquivo for válido
        if registrarAFN(nome_arquivo) == True:
            arquivo_nome = nome_arquivo
            print(f"{colors.GREEN}Arquivo inserido{colors.RESET}")
        else:
            afn = dict(afn_antigo)
    else:
        afn = dict(afn_antigo)

def arquivoValido(nome_arquivo: str):
    #Verificações do arquivo
    arq_invalido = f"{colors.FAIL}Arquivo inválido!{colors.RESET}"
    afn_invalido = f"{colors.FAIL}AFN inválido!{colors.RESET}"

    try:
        with open(nome_arquivo, "r") as f:
            arquivo = open(nome_arquivo, "r")
    except IOError:
        print(arq_invalido)
        return False
    
    linhas = arquivo.readlines()
    if len(linhas) < 4: #Se tiver menos que quatro linhas, sempre estará errado
        print(arq_invalido)
        return False

    if not("alfabeto=" in linhas[0]): #Se não tiver a linha do alfabeto=
        print(afn_invalido)
        return False
    elif not("estados=" in linhas[1]):
        print(afn_invalido)
        return False
    elif not("inicial=" in linhas[2]):
        print(afn_invalido)
        return False

    tem_finais = False #Ver se tem a linha de finais
    if "finais" in linhas[3]:
        tem_finais = True

    if tem_finais == False and not("transicoes" in linhas[3]): #Se não tiver e transições não estiver an linha 3
        print(afn_invalido)
        return False
    elif tem_finais == True and not("transicoes" in linhas[4]): #Se tiver e transições não estiver na linha 4
        print(afn_invalido)
        return False

    arquivo.close()

    return True


def registrarAFN(arquivo_nome: str):
    #Função que registra o AFN após verificar se esse é de fato válido ou se o arquivo inserido não é problemático
    global afn
    global locks
    

    arquivo = open(arquivo_nome, "r")
    linhas = arquivo.readlines()

    for i in range(len(linhas)):
        linhas[i] = linhas[i].replace(" ", "").replace("\n", "").strip()
    

    #Consideramos que há a possibilidade de existir a linha finais= para quando não há estado final ou não ter essa linha
    tem_finais = False
    if "finais" in linhas[3]:
        tem_finais = True

    for i in range(len(linhas)):
        linhas[i] = linhas[i][(linhas[i].find("=") + 1):] #As linhas são cortadas até a parte do =, que é a de fato relevante para o registro da AFN 

    
    afn["alfabeto"] = linhas[0].split(",")

    
    afn["estados"] = linhas[1].split(",")

    if "," in linhas[2]:
        print(f"{colors.FAIL}AFN inválido{colors.RESET}")
        return False
    elif not(linhas[2] in afn["estados"]):
        print(f"{colors.FAIL}AFN inválido{colors.RESET}")
        return False
    
    afn["inicial"] = linhas[2]


    if tem_finais == True:

        afn["finais"] = [] #Pode ter mais de um estado final, ou seja, é uma lista

        afn["finais"] = linhas[3].split(",") #Fazer a lista ter todos os finais em posições doferentes
        if afn["finais"][0] == "":
            pass
        else:
            for i in afn["finais"]:
                if not(i in afn["estados"]):
                    print(f"{colors.FAIL}AFN inválido{colors.RESET}")
                    return False
    else:
        afn["finais"] = []

    inicio = 0 #Determinando o início da linha de transições, já que ela pode estar na linha 4 se finais estiver omitido
    if tem_finais == False and "transicoes" in linhas[3]:
        inicio = 4
    elif tem_finais == True and "transicoes" in linhas[4]:
        inicio = 5

    transicao = ""
    estado = ""
    afn["transicoes"] = {}
    for i in range(inicio, len(linhas)):
        primeira_virgula = linhas[i].find(",") + 1 #Posição da primeira vírgula

        #Isso aqui coloca a transição nesse formato aqui: "q0,1"
        transicao = linhas[i][:(primeira_virgula)]

        aux = transicao.removesuffix(",")
        if not(aux in afn["estados"]):
            print(f"{colors.FAIL}AFN com transição inválida{colors.RESET}")
            return False

        aux = linhas[i][(linhas[i].find(",", primeira_virgula) + 1):].replace("\n", "").strip()

        if not(aux in afn["alfabeto"]) and aux != "epsilon":
            print(f"{colors.FAIL}AFN com transição inválida{colors.RESET}")
            return False
        
        transicao += aux

        if "\n" in transicao: #Mesma coisa de antes, tirar possíveis \ns e espaços vazios
            transicao = transicao.replace("\n", "").strip()

        #Estado de destino é o ente vírgulas
        estado = linhas[i][primeira_virgula: linhas[i].find(",", primeira_virgula)]

        if not(estado in afn["estados"]):
            print(f"{colors.FAIL}AFN com transição inválida{colors.RESET}")
            return False         
        
        #Se a transição ainda não tinha aparecido no arquivo, declarar uma lista para essa transição
        if afn["transicoes"].get(transicao) == None:
            afn["transicoes"][transicao] = []

        if "\n" in transicao:
            transicao = transicao.replace("\n", "").strip()

        if "\n" in estado:
            estado = estado.replace("\n", "").strip()

        if not(estado in afn["transicoes"][transicao]):
            afn["transicoes"][transicao].append(estado)
        else:
            print(f"{colors.FAIL}AFN com transições repetidas{colors.RESET}")
            return False


    locks[0] = threading.Lock()
    afn["threads_iniciais"] = 1
    threadsIniciais(afn.get("inicial"), [afn.get("inicial")])

    arquivo.close()

    return True


def threadsIniciais(estado_atual: str, transicoes_cadeia_vazia: list):
    global afn
    global locks


    transicao = estado_atual + "," + "epsilon"
    lista_threads = []

    lista_transicoes = afn.get("transicoes").get(transicao) #Calcula a transição

    if lista_transicoes == None:
        pass
    else:
        for i in range(len(lista_transicoes)):
            if not(lista_transicoes[i] in transicoes_cadeia_vazia): #Se não tiver na lista de transições
                transicoes_cadeia_vazia.append(lista_transicoes[i])

                locks[0].acquire()
                afn["threads_iniciais"] = afn.get("threads_iniciais") + 1 #Atualiza o número de threads iniciais
                locks[0].release()

                x = threading.Thread(target=threadsIniciais, args=(lista_transicoes[i],transicoes_cadeia_vazia)) #Chama uma nova thread pra continuar o cálculo
                lista_threads.append(x)
                x.start()

    for x in lista_threads: #Sempre dando join nas threads para que elas terminem antes de continuar a execução da thread principal
        x.join()


def printarArquivo():
    if (arquivo_nome != ""):
        print(arquivo_nome)
        return 

    print(f"{colors.FAIL}Arquivo não encontrado{colors.RESET}")



def verificaCadeia(cadeia: str): #Função que verifica se a cadeia é válida e está dentro do alfabeto do AFN
    alfabeto = afn.get("alfabeto")

    for caractere in cadeia: #Cada caractere da cadeia
        if not(caractere in alfabeto): #Se ele não estiver no alfabeto
            return False #Retorna falso

    return True

def interpretaCadeia(cadeia: str): #Função que é chamada pela main pra interpretar a cadeia
    #Variáveis globais que são utilizadas na função
    global numero_threads
    global string_threads
    global afn
    global locks

    numero_threads = 0 #Setando o número de threads pra 0
    string_threads = [] #Setando a string das threads pra vazia

    if arquivo_nome == "": #Se não tem arquivo registrado
        print(f"{colors.FAIL}Nenhum AFN registrado{colors.RESET}")
        return
    
    if(not verificaCadeia(cadeia)): #Se a cadeia não é válida
        print(f"{colors.FAIL}Cadeia inválida{colors.RESET}")
        return

    print("\n")

    numero_threads += 1 #Iniciando o id da primeira thread
    for lock in locks:
        lock = threading.Lock()
    
    interpretaCadeiaFuncao(cadeia, "", afn.get("inicial"), numero_threads, [afn.get("inicial")]) #Chamada da Função que fará de fato a interpretação da cadeia

    
    aceita = False 
    string_threads.sort() #Ajeitando o string_threads pra que ele fique na ordem das threads
    for string in string_threads: 
        if "Thread aceita" in string: #Se existir uma thread aceita
            aceita = True
        print(string) #Printando, agora as strings no terminal
        time.sleep(0.1)
        
    print()#\n
    if aceita == True: #Printar se a cadeia foi aceita ou não
        print(f"{colors.GREEN}Cadeia aceita{colors.RESET}\n")
    else:
        print(f"{colors.FAIL}Cadeia rejeitada{colors.RESET}\n")


def interpretaCadeiaFuncao(cadeia: str, print_string: str, estado_atual: str, id: int, transicoes_cadeia_vazia: list):
    #Ideia Geral:

    #Essa função ela é meio recursiva. Não é essencialmente recursiva porque a função nunca se chama. Porém, a thread
    #que precisar criar outra thread, criará tendo como target a própria função de início. Então, por isso ela tem diversos parâmetros,
    # para que o acesso à seção crítica seja minimizado diante da possibilidade de criação de uma quantidade grande de threads.
    # O parâmetro da cadeia é encurtado a cada vez quee um símbolo é processado, o estado atual sempre é atualizado,
    # O numero_threads é atualizado antes da criação da thread para que o id seja atualizado e a lista de transições de cadeia vazia
    # Serve para impedir o loop de transições de cadeia vazia 


    #Globais utilizadas na função
    global arquivo_nome
    global numero_threads
    global string_threads
    global afn
    global locks

    tamanho_cadeia = len(cadeia) #Tamanho da cadeia quando ela chega na função
    contador = 0 #Contador da quantidade de símbolos que já foram processados da cadeia
    lista_threads = [] #Lista de threads é sempre iniciada em zero
    crashou = False #Variável que indica se crashou ou não
    
    locks[4].acquire()
    threads_iniciais = afn.get("threads_iniciais")
    locks[4].release()


    if id > threads_iniciais: #Para a maioria das threads e para boa parte do processamento, o print_string ficar antes ou depois da
        #realização de transições de cadeia vazia não faz diferença. Porém, para as threads iniciais, ele precisa ficar depois, a fim de que o caminho do estado inicial real
        #até o estado inicial virtual não seja computado
        print_string += estado_atual + " -> "


    transicao = estado_atual + "," + "epsilon"

    lista_transicoes = afn.get("transicoes").get(transicao) #Calcula a lista de transições possíveis

    if not(estado_atual in transicoes_cadeia_vazia): #Isso serve para o primero estado em que a transição de cadeia vazia foi iniciada
        #seja computada, e o processamento não volte para esse estado no loop
        transicoes_cadeia_vazia.append(estado_atual) #Adicionando esse estado na lista de cadeia vazia

    if lista_transicoes == None: #Se não há transições de cadeia vazia 
        pass
    else:
        for i in range(len(lista_transicoes)):
            if not(lista_transicoes[i] in transicoes_cadeia_vazia): #Se o estado "final" da transição não está na lista, ou seja, se o possível loop de transições de cadeia vazia ainda poder continuar
                transicoes_cadeia_vazia.append(lista_transicoes[i]) #Colocar o estado na lista
                
                locks[0].acquire()
                numero_threads += 1
                locks[0].release()

                x = threading.Thread(target=interpretaCadeiaFuncao, args=(cadeia, print_string, lista_transicoes[i], numero_threads, transicoes_cadeia_vazia)) #Criação da thread. Nenhum símbolo foi processado, então a cadeia não precisa ser encurtada
                lista_threads.append(x)
                x.start()


    for x in lista_threads:
        x.join() #Sempre dando join nas threads, para que a interpretaCadeia() fique em standby antes de acabar o processamento das threads

    transicoes_cadeia_vazia = [] #lista de transições resetada, já que será necessário verificar a existência de loop mais adiante


    if id <= threads_iniciais:
        print_string += estado_atual + " -> " #Print_string após a cadeia vazia nas threads iniciais


    for simbolo in cadeia: #Para cada símbolo da cadeia
        transicao = estado_atual + "," + simbolo

        lista_transicoes = afn.get("transicoes").get(transicao) #Calcula a transição

        if lista_transicoes == None: #Se a transição calculada não existe, crash e fim de processamento para a thread
            print_string += f"{colors.HEADER}Thread crashou{colors.RESET}"
            crashou = True
            break

        for i in range(len(lista_transicoes)): #Iterando as transições
            if i == 0: #Certificando-se que o processamento sempre continuará na thread atual
                estado_atual = lista_transicoes[i]
            else:
                locks[1].acquire()
                numero_threads += 1
                locks[1].release()

                x = threading.Thread(target=interpretaCadeiaFuncao, args=(cadeia[contador + 1:tamanho_cadeia], print_string, lista_transicoes[i], numero_threads, transicoes_cadeia_vazia))#Criação da thread. Um dos símbolos já foi lido, então há um corte desse símbolo da cadeia 
                lista_threads.append(x)
                x.start()

        print_string += estado_atual + " -> " 

        transicao = estado_atual + "," + "epsilon"

        lista_transicoes = afn.get("transicoes").get(transicao) #Calculando transição

        if not(estado_atual in transicoes_cadeia_vazia): #Mesma coisa lá de cima
            transicoes_cadeia_vazia.append(estado_atual) 

        if lista_transicoes == None:
            pass
        else:
            # transicoes_cadeia_vazia.append(estado_atual) tenho que ver se isso ainda faz diferença
            for i in range(len(lista_transicoes)):
                if not(lista_transicoes[i] in transicoes_cadeia_vazia): #Mesma coisa lá de cima
                    transicoes_cadeia_vazia.append(lista_transicoes[i])
                    
                    locks[2].acquire()
                    numero_threads += 1
                    locks[2].release()

                    x = threading.Thread(target=interpretaCadeiaFuncao, args=(cadeia[contador + 1:tamanho_cadeia], print_string, lista_transicoes[i], numero_threads, transicoes_cadeia_vazia)) #Como essa transição de cadeia vazia é após o símbolo ser processado, então o símbolo processado tbm é cortado
                    lista_threads.append(x)
                    x.start()

        for x in lista_threads:
            x.join()

        contador += 1

        transicoes_cadeia_vazia = [] #Lista resetada para que, na próxima iteração, ele possa identificar melhor o loop

    for x in lista_threads:
        x.join()

    if crashou == True:
        pass #Se crashou, já fez o print
    else:
        if estado_atual in afn.get("finais"): #Se o estado do fim do processamento é um dos estados finais
            print_string += f"{colors.GREEN}Thread aceita{colors.RESET}"
        else: #Se não
            print_string += f"{colors.FAIL}Thread rejeitada{colors.RESET}"

    #Aqui é só pra printar as threads em ordem crescente dado os caracteres da Tabela ASCII
    if id > 9:
        print_string =  f"Thread {id} " + print_string
    else:
        print_string =  f"Thread 0{id} " + print_string

    print_string_antes = print_string

    #Isso é só pro print dos tracinhos
    if id == 1:
        aux = ""
        for i in range(145):
            aux += "-"
        aux += "\n"
        print_string = aux + print_string

    print_string = print_string + "\n"
    for i in range(145):
        print_string += "-"

    locks[3].acquire()
    string_threads.append(print_string)
    locks[3].release()
 

