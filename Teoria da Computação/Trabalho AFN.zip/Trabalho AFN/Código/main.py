import time

from funcoes import *
from cores import *

print("Bem-Vindo(a) Ao Simulador de AFN's\n")
print("------------------------------\n")
menu = 1
while(menu == 1):
    print("1. Inserir arquivo\n2. Ver arquivo\n3. Ver AFN\n4. Processar cadeia\n5. Instruções\n6. Sair\n")
    controle = input("Digite a opção desejada: ")
    match controle:
        case "1":
            teste = input("Digite o path do arquivo (Ex:teste/arquivo.txt): ")
            registrarArquivo(teste)
            time.sleep(1)
        case "2":
            printarArquivo()
            time.sleep(1)
        case "3":
            print(f"{colors.WARNING}Vendo AFN...{colors.RESET}\n")
            mostrarAFN()
            time.sleep(1)
        case "4":
            cadeia = input("Digite a cadeia a ser interpretada: ")
            interpretaCadeia(cadeia)
            time.sleep(1)
        case "5":
            print("Passo 1: Insire um arquivo com o AFN desejado escolhendo a opção 1 do menu")
            print("         O AFN precisa estar no seguinte formato:")
            print("         alfabeto=0,1\n         estados=q0,q1,q2\n         inicial=q0\n         finais=q2\n         transicoes\n         q0,q0,0\n         q0,q0,1\n         q0,q1,1\n         q1,q2,1\n         q2,q2,1\n")
            print("Espaços são tolerados, porém estados inválidos nas transições não. Não é preciso colocar estados finais\n")
            print("Se o AFN ou o arquivo forem inválidos, o AFN anterior ficará registrado")
            print("Passo 2: Interpreta a cadeia desejada com a opção 4 do menu\n")
            print(f"{colors.WARNING}Carregando...{colors.RESET}")
            time.sleep(1)
        case "6":
            print(f"{colors.WARNING}Saindo...{colors.RESET}")
            time.sleep(1)
            menu = 0
        case _:
            print(f"{colors.FAIL}Digite uma opção válida!{colors.RESET}")
            time.sleep(1)

    print("------------------------------\n")

