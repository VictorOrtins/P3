public class InvalidPositionException extends Exception{
    
}
