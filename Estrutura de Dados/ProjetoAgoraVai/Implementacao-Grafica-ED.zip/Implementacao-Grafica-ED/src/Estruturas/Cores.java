package Estruturas;

public class Cores {
    public static final String ANSI_RESET = "\u001B[0m";
    public static final String ANSI_GREEN= "\u001B[42m";
}
